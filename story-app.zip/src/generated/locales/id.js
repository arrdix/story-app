
    // Do not modify this file by hand!
    // Re-generate this file by running lit-localize

    
    

    /* eslint-disable no-irregular-whitespace */
    /* eslint-disable @typescript-eslint/no-explicit-any */

    export const templates = {
      's0487f33d9ddaabde': `Tentang`,
's1dee9519bd890fdc': `Silakan unggah foto story Anda.`,
's225ba2a1eecca3aa': `Pratinjau Story`,
's2fcb7d0d8c22a3d8': `Buat story baru`,
's4625e5cafb0ec8c7': `Teknologi`,
's47e06d5dc1bb2c0a': `Pratinjau story`,
's4b29b29baefcf90e': `Silakan masukkan nama pengguna yang valid.`,
's4b5d8dcf2271147e': `Silakan tulis deskripsi story Anda.`,
's5e6b698a2ec87331': `Buat akun`,
's6a0bc0ce56a9ae4a': `Fitur`,
's6abb1cd87fe0114e': `Beranda`,
's85366fac18679f28': `Lupa kata sandi?`,
's8da135fdef768225': `Data story dinamis`,
'sb357ea19a722d827': `Kirim`,
'sba1ea15d0a81995b': `Unggah foto`,
'sbb1aa5c8ed3a72a2': `Story Unfolds in a Snap!`,
'sc8da3cc71de63832': `Masuk`,
'scad07cc65ad2fb30': `Belum punya akun?`,
'scb04435672ac5410': `Masuk`,
'se3f5b5d9160870c1': `Silakan masukkan kata sandi yang valid.`,
'se5f4d146bbee62a2': `Saya adalah pengembang front-end yang bersemangat yang suka menghubungkan titik antara desain dan fungsionalitas.`,
'sf6f5d8ff2a4899c5': `Buat Story`,
    };
  