
    // Do not modify this file by hand!
    // Re-generate this file by running lit-localize

    
    

    /* eslint-disable no-irregular-whitespace */
    /* eslint-disable @typescript-eslint/no-explicit-any */

    export const templates = {
      's0487f33d9ddaabde': `Über`,
's1dee9519bd890fdc': `Bitte laden Sie Ihr Geschichtsfoto hoch.`,
's225ba2a1eecca3aa': `Geschichtsvorschau`,
's2fcb7d0d8c22a3d8': `Neue Geschichte veröffentlichen`,
's4625e5cafb0ec8c7': `Technologien`,
's47e06d5dc1bb2c0a': `Geschichtsvorschau`,
's4b29b29baefcf90e': `Bitte geben Sie einen gültigen Benutzernamen ein.`,
's4b5d8dcf2271147e': `Bitte schreiben Sie Ihre Geschichtsbeschreibung.`,
's5e6b698a2ec87331': `Registrieren`,
's6a0bc0ce56a9ae4a': `Funktionen`,
's6abb1cd87fe0114e': `Zuhause`,
's85366fac18679f28': `Passwort vergessen?`,
's8da135fdef768225': `Dynamische Geschichtsdaten`,
'sb357ea19a722d827': `Veröffentlichen`,
'sba1ea15d0a81995b': `Laden Sie ein Foto hoch`,
'sbb1aa5c8ed3a72a2': `Story Unfolds in a Snap!`,
'sc8da3cc71de63832': `Anmelden`,
'scad07cc65ad2fb30': `Sie haben noch keinen Account?`,
'scb04435672ac5410': `Anmelden`,
'se3f5b5d9160870c1': `Bitte geben Sie ein gültiges Passwort ein.`,
'se5f4d146bbee62a2': `Ich bin ein leidenschaftlicher Front-End-Entwickler, der Freude daran hat, die Verbindung zwischen Design und Funktionalität herzustellen.`,
'sf6f5d8ff2a4899c5': `Neuer Beitrag`,
    };
  